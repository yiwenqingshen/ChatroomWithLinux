#include "login.h"
int login(struct lr_1 *input,struct lr_1 *output)
{
   // printf("20:%s,%s, %s\n",(*input).cmd,(*input).name,(*input).password);
    FILE *openfd ;
    char rdname[10],rdpsword[10],delims[]=":";
    char recname[10],recpa[10],reccmd[5];
    char *rd_fp ;
    char readbuf[30];
     if(strcmp((*input).cmd,"rg")==0)
        {
            printf("用户注册！\n");
            openfd = fopen("login.txt","a+");
            if (openfd == NULL)
            {
                perror("Open file recfile");
                strcpy((*output).cmd,"re");
            }else
            {
               // printf("21:%s,%s, %s\n",(*input).cmd,(*input).name,(*input).password);
                bzero(rdname,sizeof(rdname));
                while(fgets(readbuf,sizeof(readbuf),openfd) != NULL)
                {
                  //  printf("3:%s",readbuf);
                    rd_fp = NULL;
                    rd_fp = strtok(readbuf,delims);
                    sprintf(rdname,"%s",rd_fp);
                  //  printf("22:%s,%s,%s\n",rd_fp,(*input).name,(*input).password);
                    if(strcmp(rdname,(*input).name) == 0)
                    {
                        strcpy((*output).name,"found");
                        strcpy((*output).cmd,"cpe");
                        strcpy((*output).password,"no");
                        fclose(openfd);
                        return 0 ;
                    }else
                    {
                        printf("3:%s",(*input).password);
                        fprintf(openfd,"%s:%s:\n",(*input).name,(*input).password);
                        strcpy((*output).cmd,"rk");
                        strcpy((*output).name,(*input).name);
                        strcpy((*output).password,(*input).password);
                        fclose(openfd);
                        return 0 ;
                    }

                }


            }
        }
        if(strcmp((*input).cmd,"lg")==0)
        {
            printf("用户登录！\n");
            openfd = fopen("login.txt","a+");
            if (openfd == NULL)
            {
                perror("Open file recfile");
                strcpy((*output).cmd,"le");
            }else
            {
                bzero(rdname,sizeof(rdname));
                bzero(rdpsword,sizeof(rdpsword));


                while(fgets(readbuf,sizeof(readbuf),openfd) != NULL)
                {
                  //  printf("4:%s",readbuf);
                    rd_fp = NULL;
                    rd_fp = strtok(readbuf,delims);
                    sprintf(rdname,"%s",rd_fp);
                 //   printf("name1: %s\n",rdname);
                 //   printf("name12 %s\n",(*input).name);
                    if(strcmp(rdname,(*input).name) == 0)
                    {
                        rd_fp = strtok(NULL,delims);
                        strcpy((*output).name,rdname);
                    //    printf("rd_fp: %s\n",rd_fp);
                        sprintf(rdpsword,"%s",rd_fp);
                      //  printf("password: %s\n",(*input).password);
                     //   printf("rdpsword: %s\n",rdpsword);
                        if(strcmp(rdpsword,(*input).password) == 0)
                        {
                        //    printf("rdpsword2: %s\n",rdpsword);
                            strcpy((*output).cmd,"lgok");
                            strcpy((*output).name ,(*input).name);
                            fclose(openfd);
                            return 0 ;
                        }else
                        {
                            strcpy((*output).cmd,"lgfl");
                            strcpy((*output).name ,"err");
                            fclose(openfd);
                            return 0 ;
                        }

                    }
                }


                        strcpy((*output).cmd,"lgfl");
                        strcpy((*output).name,"Notfd");
                        fclose(openfd);
                        return 0 ;



            }


        }

}
