#include "server.h"

void *server(void *arg)
{
    int c = 0;
    int connfd = *(int*)arg;
    init();
	while (1)
	{
	   // printf("用户 %d all！\n",connfd);
		sem_wait(&product_number);
            if(buf1[0] != '\0')
            {
              //  printf("%s\n",buf1);
                run(buf1);
                bzero(buf1,sizeof(buf1));

            }
            if(buf2[0] != '\0')
            {
                run(buf2);
                bzero(buf2,sizeof(buf2));
            }
		sem_post(&blank_number);

	}
}

void run(char *buf)
{
    struct node *p;
    char cmd[5];
    char name[10];
    char toname[10];
    char chat[150];
    int connfd,tofd;
    char *token;
    char delims[]="+";
    token = NULL ;
    token = strtok(buf,delims);
    sprintf(cmd,"%s",token);
    if(strcmp(cmd,"mk")==0)
    {

        token =strtok(NULL,delims);
       // printf("%s\n",token);
        connfd = atoi(token);
       // printf("%d\n",connfd);
        token =strtok(NULL,delims);
       // printf("%s\n",token);
        strcpy(name,token);

        p = mk_node(connfd,name);
       // printf("p:%s\n",p->name);
        insert_node(p);
        strcpy(toname,name);
        sprintf(name,"服务器");
        sprintf(chat,"欢迎 %s 加入聊天",toname);
        allsend(chat,name);
    }

     if(strcmp(cmd,"fd")==0)
    {
       // printf("fd1:%s\n",token);

        token =strtok(NULL,delims);
       // printf("fd2:%s\n",token);
        sprintf(chat,"%s",token);

        token =strtok(NULL,delims);
      //  printf("fd3:%s\n",token);
        connfd = atoi(token);
      //  printf("fd4:%d\n",connfd);

        p = findex(connfd);
     //   printf("fd5%s\n",p->name);

        sprintf(name,"%s",p->name);
        allsend(chat,name);
    }


     if(strcmp(cmd,"sl")==0)
    {
      //  printf("sl1:%s\n",token);

        token =strtok(NULL,delims);
      //  printf("sl2:%s\n",token);
        sprintf(chat,"%s",token);

        token =strtok(NULL,delims);
     //   printf("sl2:%s\n",token);
        sprintf(toname,"%s",token);

        token =strtok(NULL,delims);
      //  printf("fd3:%s\n",token);
        connfd = atoi(token);
      //  printf("fd4:%d\n",connfd);

        p = findex(connfd);
      //  printf("fd5%s\n",p->name);
        sprintf(name,"%s",p->name);

        p = findsl(toname);
        if(p!= NULL)
        {
       //     printf("fd5%s %d\n",p->name,p->connfd);
            tofd = p->connfd;
             onesend(chat,tofd,name);
        }else{

            sprintf(chat,"未找到用户！");
            onesend(chat,connfd,"服务器");
        }



    }

    if(strcmp(cmd,"ls")==0)
    {

        token =strtok(NULL,delims);
       // printf("ls3:%s\n",token);
        connfd = atoi(token);
      //  printf("ls4:%d\n",connfd);
        traverse(connfd);
    }

    if(strcmp(cmd,"rm")==0)
    {

        token =strtok(NULL,delims);
      //  printf("%s\n",token);
        connfd = atoi(token);
     //   printf("%d\n",connfd);

        p = findex(connfd);

        strcpy(toname,p->name);
        sprintf(name,"服务器");
        sprintf(chat," %s 退出聊天",toname);
        allsend(chat,name);
        rm_node(p);
    }


}
