#include "timer.h"
char timer()
{
    char *wday[]={"星期日","星期一","星期二","星期三","星期四","星期五","星期六"};
    time_t timep;
    struct tm *p;
    time(&timep);
    p=gmtime(&timep);
    printf("当前时间：%d年%d月%d日",(1900+p->tm_year), (1+p->tm_mon),p->tm_mday);
    printf("%s %d:%d:%d\n", wday[p->tm_wday], (8+p->tm_hour),p->tm_min, p->tm_sec);
}
