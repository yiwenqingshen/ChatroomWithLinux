#include "linkc.h"

void *linkc(void *arg)
{
    int lgok = 1 ;
    pthread_t  tid;
    int i;
    int p = 0;
    char cmd[5];
    tid = pthread_self();
    struct lr_1 text,input,output;
    int connfd = *(int*)arg;
    printf("服务线程创建成功，开始服务！\n");

    while(lgok)
    {
         if(read(connfd, &input, sizeof(input))==0)
        {
             printf("用户 %d 断开连接！\n",connfd);
             break;
        }
        //printf("01:%s,%s,%s\n",input.cmd,input.name,input.password);
        login(&input,&output);
        //printf("%d\n",lgok);
        if(strcmp(output.cmd,"lgok")==0)
        {
            lgok = 0 ;
         //   printf("%d\n",lgok);
        }
        //    printf("02:%s,%s,%s\n",output.cmd,output.name,output.password);
            write(connfd,&output,sizeof(output));
        if(strcmp(output.cmd,"lgok")==0)
        {
            printf("用户 :%s 连接号：%d 加入聊天服务器！加入中。。。\n",input.name,connfd);
            sem_wait(&blank_number);
            if(buf1[0] =='\0' )
            {
                sprintf(buf1,"mk+%d+%s",connfd,input.name);
              //  printf("1 mk+%d+%s",connfd,input.name);
            }else if(buf2[0] == '\0')
            {
                sprintf(buf2,"mk+%d+%s",connfd,input.name);
             //   printf("2 mk+%d+%s",connfd,input.name);
            }
            sem_post(&product_number);
            printf("用户 :%s 连接号：%d 加入成功！\n",input.name,connfd);
        }

     }
    memset(&(text),0,sizeof(text));
    while((strcmp(text.cmd,"quit")!=0)&&(lgok == 0))
    {

        if(read(connfd, &text, sizeof(text))==0)
        {
            printf("用户 %d 断开连接！\n",connfd);
            sem_wait(&blank_number);
            if(buf1[0] =='\0' )
            {
                sprintf(buf1,"rm+%d",connfd);
             //   printf("1 rm+%d",connfd);
            }else if(buf2[0] == '\0')
            {
                sprintf(buf2,"rm+%d",connfd);
             //   printf("2 rm+%d",connfd);
            }
            sem_post(&product_number);
            break;
        }

        if(strcmp(text.cmd,"1")==0)
        {
            printf("内容 %s ！\n",text.buf);
            sem_wait(&blank_number);
            if(buf1[0] =='\0' )
            {
                sprintf(buf1,"fd+%s+%d",text.buf,connfd);
            }else if(buf2[0] == '\0')
            {
                sprintf(buf1,"fd+%s+%d",text.buf,connfd);
            }
            sem_post(&product_number);

        }
         if(strcmp(text.cmd,"2")==0)
        {
            printf("内容 %s ！\n",text.buf);
            printf("目标用户：%s",text.prvtname);
            sem_wait(&blank_number);
            if(buf1[0] =='\0' )
            {
                sprintf(buf1,"sl+%s+%s+%d",text.buf,text.prvtname,connfd);


            }else if(buf2[0] == '\0')
            {
                sprintf(buf1,"sl+%s+%s+%d",text.buf,text.prvtname,connfd);

            }
            sem_post(&product_number);

        }
         if(strcmp(text.cmd,"ls")==0)
        {

            sem_wait(&blank_number);
            if(buf1[0] =='\0' )
            {
                sprintf(buf1,"ls+%d",connfd);


            }else if(buf2[0] == '\0')
            {
                sprintf(buf1,"ls+%d",connfd);

            }
            sem_post(&product_number);

        }


       // printf("1:%s,%s,%s\n",text.cmd,text.name,text.password);
        //printf("用户:%d 发来数据，线程：%u 服务",connfd,(unsigned int)tid);
       // if(write(connfd,&text,sizeof(text))<0)
       // {
       //    break ;
        //}
    }

        close(connfd);
        pthread_exit(NULL);
}
