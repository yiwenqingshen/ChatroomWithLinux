#include "cmd.h"

void init()
{
	head = &sential;
	head->next = head;
}

node *mk_node(int data,char *buf)
{
	node *p = (node *)malloc(sizeof(node));
	if (p == NULL)
	{
		printf("malloc failure\n");
		exit(1);
	}
    printf("节点:%d,用户名：%s，创建成功！\n",data,buf);
	sprintf(p->name,"%s",buf);
	p->connfd = data;
	p->next = NULL;

	return p;
}

void free_node(node *p)
{
	free(p);
}


void insert_node(node *p)
{
    p->next = head->next;
	head->next = p;
}

void traverse(int target)
{
    char namelist[100];
    char namel[12];
    bzero(namelist,sizeof(namelist));
	node *p = head->next;
   // printf("traverse1\n");
	while (p != head)
	{
	     //printf("traverse2\n");
		sprintf(namel,"%s\n", p->name);
		strcat(namelist,namel);
		printf("NAMELIST : %s",namelist);
		p = p->next;
	}
	write(target,namelist,sizeof(namelist));
}

node *findsl(char *target)
{
	node *p = head->next;

	while (p != head)
	{
		if (strcmp( p->name,target)==0)
		{
			return p;
		}
		p = p->next;
	}

	return NULL;
}

node *findex(int target)
{
	node *p = head->next;

	while (p != head)
	{
		if (p->connfd==target)
		{
		   // printf("fi%s\n",p->name);
			return p;
		}
		p = p->next;
	}

	return NULL;
}

void rm_node(node *p)
{
	node *pre = head;

	while (pre->next != head)
	{
		if (pre->next == p)
		{
			pre->next = p->next;
			return;
		}
		pre = pre->next;
	}
}
void allsend(char *buf,char *name)
{
    char bufall[200];
    sprintf(bufall,"%s 对大家说 %s",name,buf);
    printf("%s+%s",name,buf);
    printf("%s",bufall);
	node *p = head->next;

	while (p != head)
	{
		write(p->connfd,bufall,sizeof(bufall));
		p = p->next;
	}
}

void onesend(char *buf,int tofd,char *name)
{
    char bufall[200];
    sprintf(bufall,"%s 悄悄对你说 %s",name,buf);
   // printf("%s+%s",name,buf);
    write(tofd,bufall,sizeof(bufall));

}


