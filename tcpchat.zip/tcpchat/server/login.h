#ifndef _LINKC_H_

#define _LINKC_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#include <unistd.h>
#include "timer.h"
#include "linkc.h"
#include "cmd.h"


int login(struct lr_1 *input,struct lr_1 *output);

#endif


