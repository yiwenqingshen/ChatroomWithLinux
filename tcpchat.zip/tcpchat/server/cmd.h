#ifndef _CMD_H_

#define _CMD_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <semaphore.h>

#define LOGIN   0
#define REG     1
#define ALL     2
#define PRVCHAT 3

typedef struct lr_1
{
      char cmd[5];
      char name[10];
      char password[10];
      int  root;
      char buf[200];
      char prvtname[10];
}dog;

typedef struct node
{
    int connfd;
    char name[10];
    struct node *next;
}node;

struct node sential;
struct node *head;

void init();
struct node *mk_node(int data,char *buf);
void free_node(node *p);
void insert_node(node *p);
void traverse(int target);
struct node *findex(int target);
struct node *findsl(char *target);
void rm_node(node *p);
void allsend(char *buf,char *name);

#endif

