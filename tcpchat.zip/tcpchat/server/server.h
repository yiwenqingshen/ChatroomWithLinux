#ifndef _SERVER_H_

#define _SERVER_H_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#include <unistd.h>
#include "timer.h"
#include "cmd.h"
#include "login.h"
#include <semaphore.h>

#define NUM 2

int massage[NUM];
char buf1[170];
char buf2[170];

sem_t blank_number, product_number;

void *server(void *arg);
void run(char *buf);

#endif
