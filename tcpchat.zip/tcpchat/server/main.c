#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include "timer.h"
#include "linkc.h"
#include "login.h"
#include "server.h"


#define SERV_PORT 8000

int main()
{

    struct sockaddr_in servaddr, cliaddr;
    socklen_t cliaddr_len;
    int listenfd, connfd;
    char str[INET_ADDRSTRLEN];

    pthread_t cid;
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(SERV_PORT);

    bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));

    listen(listenfd, 20);

    printf("服务器打开成功，开始等待客户端连接.....\n");
    timer();
    sem_init(&blank_number, 0, NUM);
	sem_init(&product_number, 0, 0);
     if(pthread_create(&cid, NULL, server, &connfd)<0)
    {
        perror("pthread");
        exit(0);
    }
    printf("服务线程打开成功，开始等待客户端连接.....\n");
    timer();

    while(1)
    {
            cliaddr_len = sizeof(cliaddr);
            connfd = accept(listenfd,(struct sockaddr *)&cliaddr, &cliaddr_len);
            printf("用户连接：%d IP：%s 端口号：%d\n",connfd,
                    inet_ntop(AF_INET, &cliaddr.sin_addr, str, sizeof(str)),
                    ntohs(cliaddr.sin_port));
            timer();

            printf("接听线程创建。\n");
            if(pthread_create(&cid, NULL, linkc, &connfd)<0)
            {
                perror("pthread");
            }


    }
    printf("服务器关闭！\n");
    timer();
    return 0 ;
}
