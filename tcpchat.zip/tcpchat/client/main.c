#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>

#define SERV_PORT 8000

int sockfd ;//通信参数

typedef struct lr_1
{
    char cmd[5];
    char name[10];
    char password[10];
    int  root;
    char buf[200];
    char prvtname[10];
}dog;

char nowname[10];

int tcptalk(struct lr_1 *input,struct lr_1 *output);
void tcplink(char *ipnum);
//********************************************//
//名称：login   功能：登录注册****************//
//参数：NULL    返回：1成功****************//
//********************************************//
int login()
{
    struct lr_1 input,output;
    char lr[5],rg[5];
    char username[10],password[10],temp[10];
    fputs("Hello wellcome !\n",stdout);
    fputs("登录l  注册r \n",stdout);
    fscanf(stdin,"%s",lr);
    if(lr[0] == 'l')
    {
        while(strcmp(output.cmd,"lgok")!=0)
        {
	    memset(&(output),0,sizeof(output));
	    memset(&(input),0,sizeof(input));
	    if(strcmp(output.name,"err")==0)
            {
		printf("此用户名不存在或者密码错误！\n");
            	printf("请重新输入！\n");
	    }
            strcpy(input.cmd,"lg");
            fprintf(stdout,"请输入用户名：\n");
            fscanf(stdin,"%s",username);
            strcpy(input.name,username);
	    printf("请输入密码：\n");
            fscanf(stdin,"%s",password);
 	    strcpy(input.password,password);
            tcptalk(&input,&output);
        }
	    strcpy(nowname,input.name);
            printf("登录成功！\n");
            return 1;
        
    }else if(lr[0] == 'r')
    {
        fputs("请输入新用户名：\n\0",stdout);
        fscanf(stdin,"%s",username);
        strcpy(input.cmd,"rg");
        strcpy(input.name,username);
        printf("请输入密码：\n",username);
        fscanf(stdin,"%s",password);
        printf("请再次输入密码：");
        fscanf(stdin,"%s",temp);
        while(strcmp(password,temp)!=0)
        {
            printf("输入错误请重新输入！\n");
            printf("YOUR ID :%s \n请输入密码：",username);
            fscanf(stdin,"%s",password);
            printf("请再次输入密码：");
            fscanf(stdin,"%s",temp);
        }
        if(strcmp(password,temp)==0)
        {
            strcpy(input.cmd,"rg");
            strcpy(input.name,username);
            strcpy(input.password,password);
            printf("%s + %s",input.password,password);
            printf("输入正确，等待服务器确认！....");
            tcptalk(&input,&output);
       	    	while(strcmp(output.cmd,"cpe")==0)
        	{
            	printf("此用户名已经存在！\n");
            	printf("重新注册（R）or 直接登录（L）\n");
            	fscanf(stdin,"%s",rg);
            	if((rg[0]=='r')||((rg[0])=='R'))
            	{
                fputs("请输入新用户名：\n\0",stdout);
                fscanf(stdin,"%s",username);
                strcpy(input.cmd,"rg");
                strcpy(input.name,username);
                tcptalk(&input,&output);
            	}else if((rg[0]=='L')||(rg[0]=='l'))
            	{
                	return 2;
            	}else
           	 {
                printf("注册失败");
                exit(0);
            	}
        	} 
        
            printf("------注册成功------\n");
            printf("+用户名：%s        \n",output.name);
            printf("+密  码：%s        \n",output.password);
            printf("+命  令：%s        \n",output.cmd);
            printf("------欢迎使用------\n");
            return 0 ;
        }

    }
    return 0;
}
int tcptalk(struct lr_1 *input,struct lr_1 *output)
{
    struct lr_1 p;

    printf("in:%s,%s,%s, %d\n",(*input).cmd,(*input).name,(*input).password,sockfd);
    if(write(sockfd,&(*input),sizeof(*input))<0)
    {
        perror("write");
    }
    if(read(sockfd,&(*output),sizeof(*output))<0)
    {
        printf("服务器断开连接！\n");
			exit(0);
    }
    printf("out:%s %s\n",(*output).name,(*output).password);

    return 0 ;
}

void tcplink(char *ipnum)
{
    struct sockaddr_in servaddr;

    sockfd = socket(AF_INET,SOCK_STREAM,0);

    bzero(&servaddr,sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    inet_pton(AF_INET,ipnum,&servaddr.sin_addr);
    servaddr.sin_port = htons(SERV_PORT);

    if( connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0)
    {
        perror("connect");
        exit(0);
    }
}

void *waitlis(void *arg)
{
	int sockfd = *(int*)arg;
	char chat[200];
	while (1)
	{
	   	if(read(sockfd,chat,sizeof(chat))<0)
    		{
			printf("服务器断开连接！\n");
			exit(0);
        		
    		}else
		{
			printf("%s\n",chat);
		}

	}
}

int main(int argc,char *argv[])
{
    struct lr_1 text,rec;
    int loginflag=0;
    pthread_t cid;
	if(argc != 2) 
	{ 
		fprintf(stderr,"Usage:%s hostname \a\n",argv[0]); 
		exit(1); 
	} 
    tcplink(argv[1]);
    loginflag =login();
    while(loginflag == 2|| loginflag == 0)
    {
        printf("lgflag= %d\n",loginflag);
        loginflag =login();
    }
    if(loginflag == 1)
    {	
	int i ;
	    if(pthread_create(&cid, NULL, waitlis, &sockfd)<0)
            {
                perror("pthread");
            }
	system("clear");
	printf("-----------------登录成功---------------\n");
	printf("-群聊 （1） 私聊（2）  查看成员列表（3）     \n");
	printf("-用户名：%s                            \n",nowname);
	printf("-----------------登录成功---------------\n");
	while(1)
	{
		
		printf("请输入命令：\n");
		fscanf(stdin,"%s",text.cmd);
		if(strcmp(text.cmd,"1")==0)
		{
		printf("\n请输入聊天内容：");
		fscanf(stdin,"%s",text.buf);
		}	
		if(strcmp(text.cmd,"2")==0)
		{
		strcpy(text.cmd,"ls");
		printf("获取用户列表...");
		write(sockfd,&(text),sizeof(text));
		strcpy(text.cmd,"2");
		printf("请输入对方姓名：\n");
		fscanf(stdin,"%s",text.prvtname);
		printf("\n请输入聊天内容：");
		fscanf(stdin,"%s",text.buf);
			
		}
		if(strcmp(text.cmd,"3")==0)
		{
		strcpy(text.cmd,"ls");
		printf("获取用户列表...");
		}
		write(sockfd,&(text),sizeof(text));
		
	}
    }
    return 0;
}
